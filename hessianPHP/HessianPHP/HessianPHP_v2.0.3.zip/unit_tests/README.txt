To run the unit tests, you need to place simpletest in this folder
under a folder called 'simpletest'. 

If you have problems with a file called 'arguments.php', you can download it
from here: 

http://simpletest.svn.sourceforge.net/viewvc/simpletest/simpletest/trunk/arguments.php
