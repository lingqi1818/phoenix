HessianPHP 2

Hessian protocol library for PHP 5+
Licensed under the MIT license

Project home: http://code.google.com/p/hessianphp/

Manuel G�mez - 2010
vegeta.ec(a)gmail.com